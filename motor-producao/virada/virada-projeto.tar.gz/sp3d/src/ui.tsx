import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate, Easing, random, staticFile, continueRender, delayRender} from 'remotion';

// fontes locais (sem depender de rede no render)
const fontHandle = typeof window !== 'undefined' ? delayRender('fontes') : 0;
if (typeof window !== 'undefined') {
  const faces = [
    new FontFace('Garamond', `url(${staticFile('fonts/garamond.ttf')})`),
    new FontFace('Garamond', `url(${staticFile('fonts/garamond-it.ttf')})`, {style: 'italic'}),
    new FontFace('Inter', `url(${staticFile('fonts/inter.ttf')})`),
  ];
  Promise.all(faces.map((f) => f.load())).then((fs) => {
    fs.forEach((f) => (document as any).fonts.add(f));
    continueRender(fontHandle);
  });
}

export const SERIFA = 'Garamond, serif';
export const SANS = 'Inter, sans-serif';
export const LARANJA = '#ff8a3d';
export const VERMELHO = '#ff4d4d';
export const AMARELO = '#f2c94c';
export const sai = Easing.bezier(0.16, 1, 0.3, 1);
const sombra = '0 2px 10px rgba(0,0,0,0.6)';

export const fade = (f: number, a: number, b: number, c: number, d: number) =>
  interpolate(f, [a, b, c, d], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

// número que conta de 0 até o valor
export const conta = (f: number, a: number, b: number, valor: number) =>
  valor * interpolate(f, [a, b], [0, 1], {easing: sai, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

export const Contador: React.FC<{de: number; para: number; em: number}> = ({de, para, em}) => {
  const f = useCurrentFrame();
  const t = interpolate(f, [em, em + 14], [0, 1], {easing: sai, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <div style={{position: 'absolute', left: 90, top: 70, color: '#f4efe6', textShadow: sombra}}>
      <div style={{fontFamily: SANS, fontSize: 22, letterSpacing: 6, opacity: 0.8}}>DIA</div>
      <div style={{height: 104, overflow: 'hidden', fontFamily: SERIFA, fontSize: 96, lineHeight: '104px'}}>
        <div style={{transform: `translateY(${-104 * t}px)`}}>
          <div>{de}</div>
          <div>{para}</div>
        </div>
      </div>
    </div>
  );
};

export const Push: React.FC<{texto: string; em: number; ate: number}> = ({texto, em, ate}) => {
  const f = useCurrentFrame();
  const y = interpolate(f, [em, em + 12, ate, ate + 12], [-160, 40, 40, -160], {easing: sai, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const vibra = f > em + 12 && f < em + 30 ? Math.sin(f * 2.4) * 6 : 0;
  return (
    <div style={{position: 'absolute', top: y, left: '50%', transform: `translateX(calc(-50% + ${vibra}px))`, width: 620,
      background: 'rgba(24,28,40,0.88)', borderRadius: 26, padding: '20px 26px', display: 'flex', gap: 20, alignItems: 'center',
      boxShadow: '0 12px 40px rgba(0,0,0,0.45)', border: '1px solid rgba(255,255,255,0.08)'}}>
      <div style={{width: 56, height: 56, borderRadius: 14, background: LARANJA, flexShrink: 0}} />
      <div>
        <div style={{fontFamily: SANS, fontSize: 18, color: 'rgba(255,255,255,0.55)', letterSpacing: 1}}>AVISO · agora</div>
        <div style={{fontFamily: SANS, fontSize: 32, color: '#fff', fontWeight: 600}}>{texto}</div>
      </div>
    </div>
  );
};

export const Cartao: React.FC<{rotulo: string; numero: string; unidade?: string; fonte?: string; cor?: string; top?: number; o: number; dy?: number}> = ({
  rotulo, numero, unidade, fonte, cor = '#f4efe6', top = 300, o, dy = 0,
}) => (
  <div style={{position: 'absolute', left: 110, top: top + (1 - o) * 30 + dy, opacity: o, color: '#f4efe6', textShadow: sombra}}>
    <div style={{fontFamily: SANS, fontSize: 24, letterSpacing: 5, opacity: 0.85}}>{rotulo}</div>
    <div style={{fontFamily: SERIFA, fontSize: 150, lineHeight: 1.05, color: cor}}>
      {numero}
      {unidade ? <span style={{fontSize: 46, marginLeft: 14, color: '#f4efe6'}}>{unidade}</span> : null}
    </div>
    {fonte ? <div style={{fontFamily: SANS, fontSize: 18, letterSpacing: 3, opacity: 0.55}}>{fonte}</div> : null}
  </div>
);

export const Legenda: React.FC<{falas: [number, number, string][]}> = ({falas}) => {
  const f = useCurrentFrame();
  const atual = falas.find(([a, b]) => f >= a && f < b);
  if (!atual) return null;
  const [a, b, t] = atual;
  const o = fade(f, a, a + 5, b - 5, b);
  return (
    <div style={{position: 'absolute', bottom: 70, width: '100%', textAlign: 'center', opacity: o, fontFamily: SERIFA,
      fontStyle: 'italic', fontSize: 46, color: '#fff', textShadow: '0 2px 8px rgba(0,0,0,0.8)'}}>
      {t}
    </div>
  );
};

export const Grao: React.FC<{w: number; h: number}> = ({w, h}) => {
  const f = useCurrentFrame();
  const seed = Math.floor(random(f) * 1000);
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse 80% 75% at 55% 50%, rgba(0,0,0,0) 50%, rgba(5,8,18,0.6) 100%)'}} />
      <svg width={w} height={h} style={{position: 'absolute', opacity: 0.14, mixBlendMode: 'overlay'}}>
        <filter id="g">
          <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" seed={seed} />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter="url(#g)" />
      </svg>
    </AbsoluteFill>
  );
};
