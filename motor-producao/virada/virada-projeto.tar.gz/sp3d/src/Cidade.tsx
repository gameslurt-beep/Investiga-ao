import React, {useMemo} from 'react';
import * as THREE from 'three';
import {useThree} from '@react-three/fiber';
import {useCurrentFrame, interpolate, random} from 'remotion';
import {Modelo, materialNoite} from './kenney';

// cidade de prédios Kenney à noite; a luz pisca em onda e volta
const N = 30;
const passo = 1.6;
const ALTOS = ['a', 'b', 'c', 'd', 'e'].map((l) => `kenney/building-skyscraper-${l}.glb`);
const MEDIOS = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n'].map((l) => `kenney/building-${l}.glb`);
const BAIXOS = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'].map((l) => `kenney/low-detail-building-${l}.glb`);
export const PREDIOS = [...ALTOS, ...MEDIOS, ...BAIXOS];

const Camera: React.FC = () => {
  const f = useCurrentFrame();
  const cam = useThree((s) => s.camera);
  const a = interpolate(f, [0, 150], [0.6, 0.95]);
  const r = 30 - f * 0.06;
  cam.position.set(Math.cos(a) * r, 13 - f * 0.02, Math.sin(a) * r);
  cam.lookAt(-2, 2, 0);
  return null;
};

// os modelos são carregados fora do canvas (o three só redesenha quando o quadro muda)
export const Cidade: React.FC<{m: Record<string, Modelo> | null; off?: number; volta?: number}> = ({m, off = 24, volta = 56}) => {
  const f = useCurrentFrame();
  const d = useMemo(() => {
    if (!m) return null;
    const lotes: Record<string, {mat: THREE.Matrix4; off: number; volta: number}[]> = {};
    let i = 0;
    for (let gx = 0; gx < N; gx++) {
      for (let gz = 0; gz < N; gz++, i++) {
        if (gx % 5 === 0 || gz % 5 === 0) continue; // avenidas
        const x = (gx - N / 2) * passo, z = (gz - N / 2) * passo;
        const dc = Math.hypot(x, z);
        const r = random(`m${i}`);
        const lista = dc < 9 ? (r < 0.7 ? ALTOS : MEDIOS) : dc < 18 ? (r < 0.15 ? ALTOS : MEDIOS) : BAIXOS;
        const nome = lista[Math.floor(random(`n${i}`) * lista.length)];
        const mod = m[nome];
        const s = (passo * 0.86) / Math.max(mod.size.x, mod.size.z);
        const alto = 1 + (dc < 9 ? 0.9 * random(`h${i}`) : 0);
        const mat = new THREE.Matrix4().compose(
          new THREE.Vector3(x, 0, z),
          new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.floor(random(`r${i}`) * 4) * Math.PI / 2),
          new THREE.Vector3(s, s * alto, s),
        );
        // a onda do apagão começa no canto perto da câmera
        const dist = Math.hypot(x - 22, z - 22);
        (lotes[nome] = lotes[nome] || []).push({mat, off: off + dist * 0.22 + random(`o${i}`) * 4, volta: volta + random(`v${i}`) * 8});
      }
    }
    const meshes = Object.entries(lotes).map(([nome, l]) => {
      const mesh = new THREE.InstancedMesh(m[nome].geo, materialNoite(m[nome].mat), l.length);
      l.forEach((b, k) => { mesh.setMatrixAt(k, b.mat); mesh.setColorAt(k, new THREE.Color(1, 1, 1)); });
      mesh.instanceMatrix.needsUpdate = true;
      return {mesh, l};
    });
    const L = N * passo;
    const carros = Array.from({length: 120}, (_, k) => ({
      eixo: k % 2, linha: (Math.floor(random(`c${k}`) * (N / 5)) * 5 - N / 2) * passo + (k % 4 < 2 ? 0.25 : -0.25),
      ini: random(`ci${k}`) * L, vel: (0.05 + random(`cv${k}`) * 0.07) * (k % 4 < 2 ? 1 : -1),
    }));
    return {meshes, carros, L};
  }, [m, off, volta]);
  if (!d) return null;

  const c = new THREE.Color();
  d.meshes.forEach(({mesh, l}) => {
    l.forEach((b, k) => {
      let luz = f < b.off ? 1 : f < b.volta ? 0 : 1;
      if (f >= b.volta && f < b.volta + 7) luz = random(`p${k}-${f}`) > 0.5 ? 1 : 0.2; // piscadinha na volta
      mesh.setColorAt(k, c.setRGB(luz, 1, 1));
    });
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  });
  // os postes das ruas também caem junto
  const rua = f < off + 4 || f > volta + 6 ? 1 : 0.08;

  return (
    <>
      <Camera />
      <fog attach="fog" args={['#0a1020', 22, 60]} />
      <color attach="background" args={['#0a1020']} />
      {d.meshes.map(({mesh}, i) => <primitive key={i} object={mesh} />)}
      <mesh rotation-x={-Math.PI / 2} position-y={-0.01}>
        <planeGeometry args={[200, 200]} />
        <meshBasicMaterial color={new THREE.Color('#0d1322').lerp(new THREE.Color('#2a2418'), 0.35 * rua)} />
      </mesh>
      {d.carros.map((k, i) => {
        const p = (((k.ini + f * k.vel * 8) % d.L) + d.L) % d.L - d.L / 2;
        const pos: [number, number, number] = k.eixo ? [p, 0.08, k.linha] : [k.linha, 0.08, p];
        return (
          <mesh key={i} position={pos}>
            <sphereGeometry args={[0.07, 6, 6]} />
            <meshBasicMaterial color={i % 3 === 0 ? '#ff5a4a' : '#fff4d0'} />
          </mesh>
        );
      })}
    </>
  );
};
