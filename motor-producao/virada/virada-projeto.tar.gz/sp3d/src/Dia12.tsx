import React, {useEffect, useMemo, useState} from 'react';
import * as THREE from 'three';
import {useThree} from '@react-three/fiber';
import {QuadraticBezierLine, Html} from '@react-three/drei';
import {ThreeCanvas} from '@remotion/three';
import {AbsoluteFill, Sequence, OffthreadVideo, useCurrentFrame, useVideoConfig, interpolate, staticFile, delayRender, continueRender} from 'remotion';
import {shapesOf, Borda} from './Mapa';
import {useModelos, Modelo} from './kenney';
import {Cidade, PREDIOS} from './Cidade';
import {Contador, Push, Cartao, Legenda, Grao, fade, conta, sai, SANS, SERIFA, LARANJA, VERMELHO, AMARELO} from './ui';

const VERDE = '#3F6B52', VERDE_CLARO = '#7fd19b', NEUTRO = '#2A3140', OCEANO = '#0E1A33', ENERGIA = '#FFD36B';
const K = 0.93358;
// lon/lat -> mundo (o mapa fica deitado no chão: x, 0, -y)
const P = (lon: number, lat: number, h = 0) => new THREE.Vector3((lon + 48) * K, h, -(lat + 21));
const CAPITAL = P(-46.63, -23.55, 0.05);
const USINAS = [
  {nome: 'FURNAS · MG', p: P(-46.32, -20.67, 0.05)},
  {nome: 'EMBORCAÇÃO · MG', p: P(-47.98, -18.45, 0.05)},
  {nome: 'ITAIPU · PR', p: P(-54.59, -25.41, 0.05)},
];
const REFINARIAS = [
  {nome: 'REPLAN', p: P(-47.13, -22.72)},
  {nome: 'REVAP', p: P(-45.83, -23.19)},
  {nome: 'RECAP', p: P(-46.46, -23.66)},
  {nome: 'RPBC', p: P(-46.42, -23.87)},
];
const IND = ['kenney/ind/detail-tank-large.glb', 'kenney/ind/detail-tank.glb', 'kenney/ind/chimney-large.glb', 'kenney/ind/chimney-medium.glb'];
const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

function useGeo() {
  const [geo, set] = useState<any>(null);
  const [h] = useState(() => delayRender('geo'));
  useEffect(() => { fetch(staticFile('geo.json')).then((r) => r.json()).then((g) => { set(g); requestAnimationFrame(() => requestAnimationFrame(() => continueRender(h))); }); }, [h]);
  return geo;
}

// câmera: SP -> MG/PR -> zoom nas refinarias. Conteúdo fica à direita, terço da esquerda é dos cartões
const KEYS: [number, number, number, number][] = [
  // frame, alvoX, alvoZ, distância
  [130, -2.6, 1.4, 24], [380, -3.4, 1.6, 15], [430, -7.0, 0.6, 27], [600, -7.0, 0.9, 25], [670, 0.5, 2.25, 6.8], [840, 0.65, 2.3, 5.6],
];
const Camera: React.FC = () => {
  const f = useCurrentFrame();
  const cam = useThree((s) => s.camera);
  const fs = KEYS.map((k) => k[0]);
  const v = (i: number) => interpolate(f, fs, KEYS.map((k) => k[i]), {...cl, easing: sai});
  const alvo = new THREE.Vector3(v(1), 0, v(2));
  const dir = new THREE.Vector3(0.05, 0.82, 0.57).normalize();
  cam.position.copy(alvo.clone().add(dir.multiplyScalar(v(3))));
  cam.lookAt(alvo);
  return null;
};

const Estado: React.FC<{polys: any; cor: string; h?: number}> = ({polys, cor, h = 0}) => {
  const shapes = useMemo(() => shapesOf(polys), [polys]);
  return (
    <mesh position-y={h}>
      <shapeGeometry args={[shapes]} />
      <meshBasicMaterial color={cor} side={THREE.DoubleSide} />
    </mesh>
  );
};

// partículas de energia correndo pelo fio
const Fio: React.FC<{de: THREE.Vector3; ate: THREE.Vector3; em: number; corre: number}> = ({de, ate, em, corre}) => {
  const f = useCurrentFrame();
  const meio = de.clone().lerp(ate, 0.5).setY(de.distanceTo(ate) * 0.35);
  const curva = useMemo(() => new THREE.QuadraticBezierCurve3(de, meio, ate), [de, ate]);
  const t = interpolate(f, [em, em + 25], [0, 1], {...cl, easing: sai});
  if (t <= 0) return null;
  const pts = Array.from({length: 7}, (_, i) => ((corre / 40 + i / 7) % 1) * t);
  return (
    <>
      <QuadraticBezierLine start={de} end={curva.getPoint(t)} mid={de.clone().lerp(meio, t)} color={ENERGIA} lineWidth={3} transparent opacity={0.85} />
      {pts.map((p, i) => (
        <mesh key={i} position={curva.getPoint(p)}>
          <sphereGeometry args={[0.13, 10, 10]} />
          <meshBasicMaterial color="#fff3c4" />
        </mesh>
      ))}
    </>
  );
};

const Rotulo: React.FC<{p: THREE.Vector3; texto: string; o: number; cor?: string}> = ({p, texto, o, cor = '#f4efe6'}) => (
  <Html position={p} center zIndexRange={[10, 0]}>
    <div style={{opacity: o, fontFamily: SANS, fontSize: 20, letterSpacing: 3, color: cor, whiteSpace: 'nowrap', textShadow: '0 2px 8px #000',
      transform: 'translateY(-26px)'}}>{texto}</div>
  </Html>
);

const Mapa12: React.FC<{geo: any; ind: Record<string, Modelo> | null}> = ({geo, ind}) => {
  const f = useCurrentFrame();
  if (!geo || !ind) return null;

  // a chave: corta 548-578, volta depois
  const cortado = f >= 548 && f < 578;
  // a corrente para quando a chave abre (soma só o tempo ligado)
  const corre = Math.min(f, 548) + Math.max(0, f - 578);
  const destaque = interpolate(f, [400, 420, 600, 620], [0, 1, 1, 0], cl);
  const spBrilho = cortado ? 0.35 : f >= 578 && f < 586 ? (f % 2 ? 1 : 0.4) : 1;
  const spCor = new THREE.Color('#1a1d26').lerp(new THREE.Color(LARANJA), spBrilho).getStyle();
  const refT = (i: number) => interpolate(f, [640 + i * 12, 662 + i * 12], [0, 1], {...cl, easing: sai});
  const brasil = interpolate(f, [700, 716], [0, 1], cl); // refinarias ganham a cor do Brasil
  const sp = geo.states.find((s: any) => s.sigla === 'SP');

  return (
    <>
      <Camera />
      <color attach="background" args={[OCEANO]} />
      <group rotation-x={-Math.PI / 2}>
        {geo.neighbors.map((n: any) => <Estado key={n.name} polys={n.polys} cor={NEUTRO} />)}
        {geo.states.filter((s: any) => s.sigla !== 'SP').map((s: any) => {
          const cita = s.sigla === 'MG' || s.sigla === 'PR';
          const cor = cita ? new THREE.Color(VERDE).lerp(new THREE.Color(AMARELO), destaque * 0.85).getStyle() : VERDE;
          return <Estado key={s.sigla} polys={s.polys} cor={cor} />;
        })}
        {geo.states.map((s: any) => <Borda key={s.sigla} rings={s.polys.map((p: any) => p[0])} width={1.2} color="#0b1428" opacity={0.9} z={0.01} />)}
        <Estado polys={sp.polys} cor={spCor} h={0.02} />
        <Borda rings={sp.polys.map((p: any) => p[0])} width={6} color={LARANJA} opacity={0.55 * spBrilho} z={0.03} additive />
      </group>

      {USINAS.map((u, i) => (
        <group key={u.nome}>
          {f < 615 ? <Fio de={u.p} ate={CAPITAL} em={415 + i * 18} corre={cortado ? 548 : corre} /> : null}
          <Rotulo p={u.p} texto={u.nome} o={fade(f, 420 + i * 18, 435 + i * 18, 600, 615)} cor={AMARELO} />
        </group>
      ))}

      {REFINARIAS.map((r, i) => {
        const t = refT(i);
        if (t <= 0) return null;
        const s = 0.17 * t;
        const tanque = new THREE.Color('#c9ced8').lerp(new THREE.Color(i % 2 ? AMARELO : VERDE_CLARO), brasil);
        return (
          <group key={r.nome} position={r.p}>
            {[[-0.12, 0, IND[0]], [0.12, 0.08, IND[1]], [0.02, -0.14, IND[2]], [-0.16, -0.12, IND[3]]].map(([x, z, a], k) => (
              <mesh key={k} geometry={ind[a as string].geo} position={[x as number, 0, z as number]} scale={[s, s, s]}>
                <meshBasicMaterial map={ind[a as string].mat.map} color={k < 2 ? tanque : '#ffffff'} />
              </mesh>
            ))}
            <Rotulo p={new THREE.Vector3(0, r.nome === 'RPBC' ? -0.05 : 0.3, r.nome === 'RPBC' ? 0.35 : 0)} texto={r.nome} o={t} />
          </group>
        );
      })}
    </>
  );
};

const Barras: React.FC = () => {
  const f = useCurrentFrame();
  const o = fade(f, 255, 268, 385, 398);
  const c = interpolate(f, [262, 300], [0, 1], {...cl, easing: sai});
  const g = interpolate(f, [290, 335], [0, 0.45], {...cl, easing: sai});
  const pisca = f > 335 ? (Math.floor(f / 5) % 2 ? 1 : 0.35) : 0;
  const W = 520;
  const linha = (rot: string, frac: number, cor: string, num: string) => (
    <div style={{marginBottom: 26}}>
      <div style={{fontFamily: SANS, fontSize: 22, letterSpacing: 4, color: '#f4efe6', opacity: 0.85, marginBottom: 8}}>{rot} <span style={{fontFamily: SERIFA, fontSize: 40, letterSpacing: 0, marginLeft: 10}}>{num}</span></div>
      <div style={{width: W, height: 34, background: 'rgba(255,255,255,0.08)', position: 'relative'}}>
        <div style={{width: W * frac, height: 34, background: cor}} />
      </div>
    </div>
  );
  return (
    <div style={{position: 'absolute', left: 110, top: 560, opacity: o}}>
      {linha('SP CONSOME', c, LARANJA, '100%')}
      <div style={{position: 'relative'}}>
        {linha('SP GERA', g, ENERGIA, `${Math.round(g * 100)}%`)}
        <div style={{position: 'absolute', left: W * 0.45, top: 46, width: W * 0.55, height: 34, border: `3px solid ${VERMELHO}`, opacity: pisca,
          background: 'rgba(255,77,77,0.18)', boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: SANS, fontSize: 20, letterSpacing: 3, color: VERMELHO, fontWeight: 700}}>▼ FALTAM 55%</div>
      </div>
    </div>
  );
};

const Chave: React.FC = () => {
  const f = useCurrentFrame();
  const o = fade(f, 500, 515, 600, 612);
  const ligado = !(f >= 548 && f < 578);
  const x = interpolate(f, [545, 551, 575, 581], [1, 0, 0, 1], cl);
  return (
    <div style={{position: 'absolute', left: 110, top: 560, opacity: o, display: 'flex', alignItems: 'center', gap: 28}}>
      <div style={{width: 170, height: 84, borderRadius: 42, background: ligado ? VERDE : '#3a3f4c', position: 'relative', boxShadow: '0 6px 24px rgba(0,0,0,0.5)'}}>
        <div style={{position: 'absolute', top: 7, left: 7 + x * 86, width: 70, height: 70, borderRadius: 35, background: '#f4efe6'}} />
      </div>
      <div style={{fontFamily: SANS, fontSize: 30, letterSpacing: 4, color: ligado ? '#f4efe6' : VERMELHO, fontWeight: 600}}>{ligado ? 'LIGADO' : 'DESLIGADO'}</div>
    </div>
  );
};

const FALAS: [number, number, string][] = [
  [4, 46, 'Você está no banho quando a luz pisca.'],
  [50, 88, 'E volta.'],
  [94, 140, 'Mas o recado foi dado.'],
  [150, 248, 'São Paulo gasta um quarto da energia do Brasil…'],
  [252, 384, '…e gera menos da metade do que consome.'],
  [392, 500, 'O resto chega por fios, de usinas em Minas, no Paraná…'],
  [505, 602, 'E quem tem a mão na chave agora é o Brasil.'],
  [610, 660, 'E a gasolina?'],
  [664, 762, 'As refinarias ficam em São Paulo. Mas são da Petrobras.'],
  [766, 840, 'E a Petrobras agora é de outro país.'],
];

// números, cartões e legendas: os mesmos nas duas versões (código e Flow)
const Camadas: React.FC<{falas: [number, number, string][]; fundo?: number}> = ({falas, fundo = 0.9}) => {
  const f = useCurrentFrame();
  const oMapa = interpolate(f, [125, 150], [0, 1], cl);
  return (
    <>
      {/* fundo escuro no terço da esquerda para os cartões lerem por cima do mapa */}
      <AbsoluteFill style={{opacity: oMapa, background: `linear-gradient(90deg, rgba(10,18,38,${fundo}) 0%, rgba(10,18,38,${fundo * 0.72}) 30%, rgba(10,18,38,0) 50%)`}} />
      <Cartao rotulo="CONSUMO DE ELETRICIDADE" numero={`${Math.round(conta(f, 165, 205, 26))}%`} unidade="do Brasil" fonte="BALANÇO ENERGÉTICO DO ESTADO DE SP" cor={LARANJA} top={250} o={fade(f, 160, 172, 385, 398)} />
      <Cartao rotulo="CHEGA DE FORA, POR FIO" numero={`${Math.round(conta(f, 405, 445, 55))}%`} unidade="MG · PR" cor={ENERGIA} top={250} o={fade(f, 400, 412, 495, 505)} />
      <Cartao rotulo="QUEM TEM A MÃO NA CHAVE" numero="BRASIL" cor={VERDE_CLARO} top={250} o={fade(f, 505, 517, 600, 612)} />
      <Barras />
      <Chave />
      <Cartao rotulo="REFINARIAS EM SP" numero={`${Math.round(conta(f, 640, 690, 4))}`} fonte="REPLAN · REVAP · RECAP · RPBC" top={250} o={fade(f, 625, 637, 836, 840)} />
      <Cartao rotulo="DONA" numero="Petrobras" cor={VERDE_CLARO} top={560} o={fade(f, 690, 702, 836, 840)} dy={-30} />
      <div style={{position: 'absolute', left: 114, top: 760, opacity: fade(f, 770, 780, 836, 840), fontFamily: SANS, fontSize: 30, letterSpacing: 5,
        color: VERMELHO, fontWeight: 700, transform: `scale(${interpolate(f, [770, 780], [1.3, 1], cl)})`, transformOrigin: 'left'}}>▼ AGORA, DE OUTRO PAÍS</div>

      <Legenda falas={falas} />
    </>
  );
};

export const Dia12: React.FC = () => {
  const f = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const geo = useGeo();
  const ind = useModelos(IND);
  const predios = useModelos(PREDIOS);
  // o canvas só monta com tudo carregado: o three só redesenha quando o quadro muda
  if (!geo || !ind || !predios) return null;
  const oMapa = interpolate(f, [125, 150], [0, 1], cl);
  return (
    <AbsoluteFill style={{background: OCEANO}}>
      <Sequence durationInFrames={152}>
        <ThreeCanvas width={width} height={height} camera={{fov: 34, near: 0.1, far: 200}} gl={{antialias: true}}>
          <Cidade m={predios} off={24} volta={56} />
        </ThreeCanvas>
      </Sequence>
      <Sequence from={120}>
        <AbsoluteFill style={{opacity: oMapa}}>
          <ThreeCanvas width={width} height={height} camera={{fov: 30, near: 0.1, far: 300}} gl={{antialias: true}}>
            <Sequence from={-120} layout="none"><Mapa12 geo={geo} ind={ind} /></Sequence>
          </ThreeCanvas>
        </AbsoluteFill>
      </Sequence>

      <Camadas falas={FALAS} />
      <Contador de={11} para={12} em={8} />
      <Push texto="Faltam 18 dias." em={6} ate={84} />
      <Grao w={width} h={height} />
    </AbsoluteFill>
  );
};

// versão B: os vídeos do Flow no fundo, as mesmas camadas por cima (atrasadas 100 quadros, porque a cidade do Flow dura 8 s)
const ATRASO = 100;
export const Dia12Flow: React.FC = () => {
  const f = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const cortado = f >= 548 + ATRASO && f < 578 + ATRASO;
  const inicio: [number, number, string][] = [[4, 92, 'Você está no banho quando a luz pisca.'], [196, 222, 'E volta.'], [224, 250, 'Mas o recado foi dado.']];
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Sequence durationInFrames={240}><OffthreadVideo src={staticFile('flow12/T1_cidade_noite.mp4')} muted /></Sequence>
      <Sequence from={240} durationInFrames={460}>
        <AbsoluteFill style={{filter: cortado ? 'brightness(0.25) saturate(0.3)' : 'none'}}>
          <OffthreadVideo src={staticFile('flow12/T2_usina_linhas.mp4')} playbackRate={0.4} muted />
        </AbsoluteFill>
      </Sequence>
      <Sequence from={700}><OffthreadVideo src={staticFile('flow12/T3_refinaria.mp4')} playbackRate={0.75} muted /></Sequence>
      <Sequence from={ATRASO}><Camadas falas={FALAS.slice(3)} fundo={0.85} /></Sequence>
      <Legenda falas={inicio} />
      <Contador de={11} para={12} em={8} />
      <Push texto="Faltam 18 dias." em={6} ate={84} />
      <Grao w={width} h={height} />
    </AbsoluteFill>
  );
};
