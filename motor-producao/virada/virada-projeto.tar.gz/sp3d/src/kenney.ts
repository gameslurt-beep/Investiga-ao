import {useEffect, useState} from 'react';
import * as THREE from 'three';
import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js';
import {mergeGeometries} from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import {staticFile, delayRender, continueRender} from 'remotion';

// carrega GLBs do Kenney e junta cada um numa geometria só (para instanciar)
export type Modelo = {geo: THREE.BufferGeometry; mat: THREE.MeshStandardMaterial; size: THREE.Vector3};

export function useModelos(arquivos: string[]) {
  const [m, setM] = useState<Record<string, Modelo> | null>(null);
  const [h] = useState(() => delayRender('kenney'));
  useEffect(() => {
    const loader = new GLTFLoader();
    Promise.all(arquivos.map((a) => loader.loadAsync(staticFile(a)))).then((gs) => {
      const out: Record<string, Modelo> = {};
      gs.forEach((g, i) => {
        g.scene.updateMatrixWorld(true);
        const geos: THREE.BufferGeometry[] = [];
        let mat: any = null;
        g.scene.traverse((o: any) => {
          if (!o.isMesh) return;
          const geo = o.geometry.clone().applyMatrix4(o.matrixWorld);
          ['position', 'normal', 'uv'].forEach((k) => { if (!geo.attributes[k]) geo.setAttribute(k, new THREE.BufferAttribute(new Float32Array(geo.attributes.position.count * (k === 'uv' ? 2 : 3)), k === 'uv' ? 2 : 3)); });
          Object.keys(geo.attributes).forEach((k) => { if (!['position', 'normal', 'uv'].includes(k)) geo.deleteAttribute(k); });
          geos.push(geo.index ? geo.toNonIndexed() : geo);
          mat = mat || (Array.isArray(o.material) ? o.material[0] : o.material);
        });
        const geo = mergeGeometries(geos)!;
        geo.computeBoundingBox();
        const b = geo.boundingBox!;
        geo.translate(-(b.min.x + b.max.x) / 2, -b.min.y, -(b.min.z + b.max.z) / 2);
        out[arquivos[i]] = {geo, mat, size: b.getSize(new THREE.Vector3())};
      });
      setM(out);
      // espera o three desenhar antes de liberar o quadro
      requestAnimationFrame(() => requestAnimationFrame(() => continueRender(h)));
    });
  }, []);
  return m;
}

// material de noite: janelas (texels azulados do colormap) acendem em amarelo conforme a cor da instância (r = luz)
export function materialNoite(base: THREE.MeshStandardMaterial) {
  const mat = new THREE.MeshBasicMaterial({map: base.map});
  mat.onBeforeCompile = (s) => {
    s.fragmentShader = s.fragmentShader.replace(
      '#include <map_fragment>',
      `#include <map_fragment>
      float luz = vColor.r;
      vec3 c = diffuseColor.rgb;
      // vidro do colormap (linear): azul bem mais forte que o vermelho; paredes cinza-azuladas ficam de fora
      float janela = step(0.3, c.b - c.r) * step(c.g, c.b);
      vec3 noite = c * vec3(0.045, 0.055, 0.1) * (0.4 + 0.6 * luz);
      diffuseColor.rgb = mix(noite, vec3(1.0, 0.66, 0.28), janela * luz);
`,
    ).replace('#include <color_fragment>', '');
  };
  mat.vertexColors = false;
  return mat;
}
