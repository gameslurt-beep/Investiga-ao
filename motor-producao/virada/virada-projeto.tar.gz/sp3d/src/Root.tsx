import React from 'react';
import {Composition} from 'remotion';
import {Abertura} from './Abertura';
import {Dia12, Dia12Flow} from './Dia12';
import {Dia3} from './Dia3';
import {Dia3Mix, DIA3MIX_LEN} from './Dia3Mix';
import {Virada, VIRADA_LEN} from './Virada';

export const Root: React.FC = () => (
  <>
  <Composition id="Virada" component={Virada} durationInFrames={VIRADA_LEN} fps={30} width={1080} height={1920} />
  <Composition id="Dia3Mix" component={Dia3Mix} durationInFrames={DIA3MIX_LEN} fps={30} width={1920} height={1080} />
  <Composition id="Dia3" component={Dia3} durationInFrames={900} fps={30} width={1920} height={1080} />
  <Composition id="Dia12Flow" component={Dia12Flow} durationInFrames={940} fps={30} width={1920} height={1080} />
  <Composition id="Dia12" component={Dia12} durationInFrames={840} fps={30} width={1920} height={1080} />
  <Composition id="Abertura" component={Abertura} durationInFrames={110} fps={30} width={1080} height={1920} />
  </>
);
