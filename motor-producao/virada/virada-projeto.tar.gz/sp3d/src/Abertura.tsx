import React, {useMemo} from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate, random} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {SERIFA} from './ui';
import {Mapa, useAssets} from './Mapa';

const fontFamily = SERIFA;

const Titulo: React.FC = () => {
  const sombra = '0 2px 6px rgba(0,0,0,0.55), 0 0 24px rgba(0,0,0,0.35)';
  return (
    <AbsoluteFill style={{alignItems: 'center', fontFamily, color: '#f4efe6', textShadow: sombra}}>
      <div style={{position: 'absolute', top: 470, fontSize: 60, fontStyle: 'italic', fontWeight: 400}}>E se</div>
      <div style={{position: 'absolute', top: 560, fontSize: 92, fontWeight: 500, lineHeight: 1.14, textAlign: 'center'}}>
        São Paulo virasse
        <br />
        um país?
      </div>
    </AbsoluteFill>
  );
};

// grão de filme que muda a cada quadro + vinheta
const Grao: React.FC = () => {
  const frame = useCurrentFrame();
  const seed = Math.floor(random(frame) * 1000);
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <AbsoluteFill
        style={{background: 'radial-gradient(ellipse 75% 60% at 50% 48%, rgba(0,0,0,0) 45%, rgba(5,8,18,0.55) 100%)'}}
      />
      <svg width="1080" height="1920" style={{position: 'absolute', opacity: 0.16, mixBlendMode: 'overlay'}}>
        <filter id="g">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed={seed} />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter="url(#g)" />
      </svg>
    </AbsoluteFill>
  );
};

export const Abertura: React.FC = () => {
  const {width, height} = useVideoConfig();
  const a = useAssets();
  if (!a) return null;
  return (
    <AbsoluteFill style={{backgroundColor: '#0e1a33'}}>
      <ThreeCanvas style={{filter: 'saturate(0.82) contrast(0.93) brightness(1.02)'}} width={width} height={height} shadows camera={{fov: 30, near: 0.1, far: 200}} gl={{antialias: true}}>
        <Mapa a={a} />
      </ThreeCanvas>
      <Titulo />
      <Grao />
    </AbsoluteFill>
  );
};
