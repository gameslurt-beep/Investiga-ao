import React, {useEffect, useMemo, useState} from 'react';
import * as THREE from 'three';
import {useThree} from '@react-three/fiber';
import {useCurrentFrame, interpolate, Easing, staticFile, delayRender, continueRender} from 'remotion';
import {Line2} from 'three/examples/jsm/lines/Line2.js';
import {LineMaterial} from 'three/examples/jsm/lines/LineMaterial.js';
import {LineGeometry} from 'three/examples/jsm/lines/LineGeometry.js';

type Ring = number[][];
type Geo = {
  states: {sigla: string; polys: Ring[][]}[];
  neighbors: {name: string; polys: Ring[][]}[];
  tex: {lonMin: number; lonMax: number; latMin: number; latMax: number; lon0: number; lat0: number; k: number};
};

const D = 0.8; // espessura da placa
export const PELE: 'satelite' | 'flow' = 'flow';
const ease = Easing.bezier(0.45, 0, 0.2, 1);

export function useAssets() {
  const [data, setData] = useState<{geo: Geo; tex: Record<string, THREE.Texture>} | null>(null);
  const [handle] = useState(() => delayRender('assets'));
  useEffect(() => {
    const loader = new THREE.TextureLoader();
    const load = (f: string) => loader.loadAsync(staticFile(f));
    // PELE = 'flow': uma imagem só (mapa exato repintado no Flow) cobre estados, SP e vizinhos
    const flow = PELE === 'flow';
    Promise.all([
      fetch(staticFile('geo.json')).then((r) => r.json()),
      flow ? fetch(staticFile('base_mapa.json')).then((r) => r.json()) : null,
      load(flow ? 'flow/01.jpg' : 'sat_green.jpg'),
      load(flow ? 'flow/01.jpg' : 'sat_orange.jpg'),
      load(flow ? 'flow/01.jpg' : 'sat_grey.jpg'),
      load(flow ? 'flow/03.jpg' : 'strata.png'),
    ]).then(([geo, base, green, orange, grey, strata]) => {
      if (base) geo.tex = {...geo.tex, ...base};
      setData({geo, tex: {green, orange, grey, strata}});
      continueRender(handle);
    });
  }, [handle]);
  return data;
}

export const shapesOf = (polys: Ring[][]) =>
  polys.map((p) => new THREE.Shape(p[0].map(([x, y]) => new THREE.Vector2(x, y))));

function capTexture(base: THREE.Texture, t: Geo['tex']) {
  const tx = base.clone();
  const W = t.lonMax - t.lonMin, H = t.latMax - t.latMin;
  tx.colorSpace = THREE.SRGBColorSpace;
  tx.anisotropy = 8;
  tx.repeat.set(1 / (t.k * W), 1 / H);
  tx.offset.set((t.lon0 - t.lonMin) / W, (t.lat0 - t.latMin) / H);
  tx.needsUpdate = true;
  return tx;
}

function sideTexture(base: THREE.Texture) {
  const tx = base.clone();
  tx.colorSpace = THREE.SRGBColorSpace;
  tx.wrapS = tx.wrapT = THREE.ClampToEdgeWrapping;
  // na pele do Flow a imagem tem muitas camadas: usa só a faixa de cima (35%)
  const f = PELE === 'flow' ? 0.35 : 1;
  tx.repeat.set(1, -f / D);
  tx.offset.set(0, 1 - f + f / D);
  tx.needsUpdate = true;
  return tx;
}

export const Borda: React.FC<{rings: Ring[]; width: number; color: string; opacity: number; z?: number; additive?: boolean}> = ({
  rings, width, color, opacity, z = 0.004, additive,
}) => {
  const size = useThree((s) => s.size);
  const lines = useMemo(() => {
    const mat = new LineMaterial({color, linewidth: width, transparent: true, opacity, depthWrite: false,
      blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending});
    mat.resolution.set(size.width, size.height);
    return rings.map((r) => {
      const g = new LineGeometry();
      g.setPositions(r.flatMap(([x, y]) => [x, y, z]).concat([r[0][0], r[0][1], z]));
      const l = new Line2(g, mat);
      l.computeLineDistances();
      return l;
    });
  }, [rings, width, color, opacity, z, additive, size]);
  return <>{lines.map((l, i) => <primitive key={i} object={l} />)}</>;
};

const Camera: React.FC = () => {
  const frame = useCurrentFrame();
  const camera = useThree((s) => s.camera);
  // empurrão lento para dentro, como no original
  const t = interpolate(frame, [0, 110], [0, 1], {extrapolateRight: 'clamp'});
  const alvo = new THREE.Vector3(-0.2, 0, -0.6 + t * 0.3);
  const dist = 42 - t * 4;
  const dir = new THREE.Vector3(0.14, 0.68, 0.72).normalize();
  camera.position.copy(alvo.clone().add(dir.multiplyScalar(dist)));
  camera.lookAt(alvo);
  camera.updateProjectionMatrix();
  return null;
};

const Poeira: React.FC<{rings: Ring[]; frame: number}> = ({rings, frame}) => {
  const {pts, tex} = useMemo(() => {
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const g = c.getContext('2d')!; const r = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    r.addColorStop(0, 'rgba(255,240,230,0.9)'); r.addColorStop(1, 'rgba(255,240,230,0)');
    g.fillStyle = r; g.fillRect(0, 0, 64, 64);
    const ring = rings.reduce((a, b) => (a.length > b.length ? a : b));
    const pts = Array.from({length: 260}, (_, i) => {
      const p = ring[Math.floor((i * 7919) % ring.length)];
      return {x: p[0], y: p[1], d: ((i * 37) % 100) / 100, s: 0.25 + ((i * 53) % 100) / 220};
    });
    return {pts, tex: new THREE.CanvasTexture(c)};
  }, [rings]);
  const vida = interpolate(frame, [18, 40, 110], [0, 1, 0.35], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <>
      {pts.map((p, i) => {
        const t = ((frame - 18) / 60 + p.d) % 1;
        if (frame < 18) return null;
        return (
          <sprite key={i} position={[p.x, p.y, 0.1 + t * 1.2]} scale={[p.s * (1 + t), p.s * (1 + t), 1]}>
            <spriteMaterial map={tex} transparent depthWrite={false} opacity={vida * 0.3 * Math.sin(Math.PI * t)} />
          </sprite>
        );
      })}
    </>
  );
};

export type Assets = {geo: Geo; tex: Record<string, THREE.Texture>};
export const Mapa: React.FC<{a: Assets | null}> = ({a}) => {
  const frame = useCurrentFrame();

  const built = useMemo(() => {
    if (!a) return null;
    const {geo, tex} = a;
    const ext = {depth: D, bevelEnabled: false, curveSegments: 1};
    const side = new THREE.MeshStandardMaterial({map: sideTexture(tex.strata), roughness: 0.9});
    const green = new THREE.MeshStandardMaterial({map: capTexture(tex.green, geo.tex), roughness: 0.85});
    const grey = new THREE.MeshStandardMaterial({map: capTexture(tex.grey, geo.tex), roughness: 0.9});
    const orange = new THREE.MeshStandardMaterial({map: capTexture(tex.orange, geo.tex), roughness: 0.8,
      emissive: new THREE.Color('#ff7a1a'), emissiveIntensity: 0});
    const sp = geo.states.find((s) => s.sigla === 'SP')!;
    const outros = geo.states.filter((s) => s.sigla !== 'SP');
    return {
      side, orange,
      outros: outros.map((s) => new THREE.ExtrudeGeometry(shapesOf(s.polys), ext)),
      vizinhos: geo.neighbors.map((n) => new THREE.ExtrudeGeometry(shapesOf(n.polys), {...ext, depth: D * 0.9})),
      sp: new THREE.ExtrudeGeometry(shapesOf(sp.polys), ext),
      buraco: new THREE.ShapeGeometry(shapesOf(sp.polys)),
      green, grey,
      bordas: outros.flatMap((s) => s.polys.map((p) => p[0])),
      bordaSP: sp.polys.map((p) => p[0]),
    };
  }, [a]);

  if (!built) return null;

  // animação de SP: brilho na borda, depois se solta e sobe
  const brilho = interpolate(frame, [0, 10, 30, 55, 110], [0.35, 0.6, 1, 0.55, 0.3], {extrapolateRight: 'clamp'});
  const sobe = interpolate(frame, [22, 70], [0, 1], {easing: ease, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  built.orange.emissiveIntensity = 0.04 + 0.1 * brilho;

  return (
    <>
      <Camera />
      <ambientLight intensity={0.55} color="#c9d6ff" />
      <hemisphereLight args={['#fff2dd', '#1b2a4a', 0.5]} />
      <directionalLight
        position={[-9, 16, 6]}
        intensity={2.6}
        color="#fff1dc"
        castShadow
        shadow-mapSize={[4096, 4096]}
        shadow-camera-left={-14}
        shadow-camera-right={14}
        shadow-camera-top={14}
        shadow-camera-bottom={-14}
        shadow-bias={-0.0004}
        shadow-radius={6}
      />
      {/* oceano */}
      <mesh rotation-x={-Math.PI / 2} position-y={-D - 0.02} receiveShadow>
        <planeGeometry args={[200, 200]} />
        <meshStandardMaterial color="#14254a" roughness={0.55} metalness={0.1} />
      </mesh>
      <group rotation-x={-Math.PI / 2}>
        <group position-z={-D}>
          {built.outros.map((g, i) => (
            <mesh key={i} geometry={g} material={[built.green, built.side]} castShadow receiveShadow />
          ))}
          {built.vizinhos.map((g, i) => (
            <mesh key={'v' + i} geometry={g} material={[built.grey, built.side]} receiveShadow />
          ))}
          {/* fundo escuro do buraco que SP deixa */}
          <mesh geometry={built.buraco} position-z={0.02}>
            <meshStandardMaterial color="#1c120d" roughness={1} />
          </mesh>
        </group>
        <Poeira rings={built.bordaSP} frame={frame} />
        <Borda rings={built.bordas} width={2.2} color="#f3f1ea" opacity={0.55} />
        {/* SP se soltando */}
        <group position={[-0.1 * sobe, 0.4 * sobe, 0.9 * sobe]} rotation={[0.07 * sobe, -0.04 * sobe, 0]}>
          <mesh geometry={built.sp} material={[built.orange, built.side]} position-z={-D} castShadow receiveShadow />
          <Borda rings={built.bordaSP} width={2.4} color="#ffe9df" opacity={0.85} z={0.006} />
          <Borda rings={built.bordaSP} width={6} color="#ffb59a" opacity={0.28 * brilho} z={0.005} additive />
          <Borda rings={built.bordaSP} width={14} color="#ff9a7a" opacity={0.12 * brilho} z={0.004} additive />
        </group>
      </group>
    </>
  );
};
